#ifndef SAUVEGARDE_H_INCLUDED
#define SAUVEGARDE_H_INCLUDED
#include "Graphe.h"
Graphe charger();

#endif // SAUVEGARDE_H_INCLUDED
